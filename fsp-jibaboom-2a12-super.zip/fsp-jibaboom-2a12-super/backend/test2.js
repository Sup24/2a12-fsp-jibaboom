rewire = require('rewire');

rewiredApp = rewire('/app');

rewiredApp