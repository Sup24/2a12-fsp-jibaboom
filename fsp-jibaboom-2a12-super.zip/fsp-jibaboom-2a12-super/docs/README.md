# Github Pages

This is the folder that will host your files for Github pages. i.e. built from your frontend.
