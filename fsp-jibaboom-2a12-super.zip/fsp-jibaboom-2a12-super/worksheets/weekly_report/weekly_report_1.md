Supraja and Asher's Week 1 Weekly Report
# Weekly Report

This report is for you to document the progres of your project. You should also document any change in plan, e.g. change in design or change in API specification or change in work allocation. The following is a template for you to follow.

## What I have done last week
I have installed git on my computer using the zip file provided in FSP teams. I have also set up my github account.
My partner had accepted the assignment so I just searched for FSP team in github (which I was added to) then I joined my team, accepting the assignment. After that, I updated the readme.md file and replaced name with my name. Then I cloned my repository, staged my changes and committed my file. We decided on problem statement- Meeting Time Voter.
## What do I plan to do next week(Week 2)
I plan to start some planning about the assignment with my partner and probably start dividing work.
Watch recap videos (both of us)
Decide on tools to use
Decide on technology to use
Create necessary milestones and issues on github
Read the rubrics 
Identify questions to ask (if any)
## Additional Thoughts 
Asher won't wake up late again.
Supraja will try to be more attentive in the morning.
