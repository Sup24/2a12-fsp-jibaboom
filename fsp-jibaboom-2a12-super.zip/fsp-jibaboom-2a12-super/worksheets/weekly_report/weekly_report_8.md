# Weekly Report
 
This report is for you to document the progres of your project. You should also document any change in plan, e.g. change in design or change in API specification or change in work allocation. The following is a template for you to follow.
 
## What have I done last week
 
-   Worked on gettingAvailabilitiesForComputation function and made it work
-   Resolved index.js line 53 (callback is not a function) error
-   Completed Result Viewer Frontend
-   Added more issues and milestones 
 
## What do I plan to do next week
 
-   Basic Result API - Make it work 
-   Modify functions related to result API
-   Start Advanced Data and Result Viewer Frontend
-   Make the algorithm work
 
## Additional Thoughts
 
-   Counting Overlapping Intervals - so tough!!
-   Duration .. howwwwww
-   Lecturer is awesome.