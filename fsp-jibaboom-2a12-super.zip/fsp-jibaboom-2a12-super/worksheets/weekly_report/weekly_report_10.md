# Weekly Report

This report is for you to document the progres of your project. You should also document any change in plan, e.g. change in design or change in API specification or change in work allocation. The following is a template for you to follow.

## What have I done last week

-   Fixed basic result frontend
-   Worked on result API (basic and advanced)
-   95% of basic result completed (first challenge incomplete)
-   Worked on adv rv frontend (finished html)
-   Finished and finalised basic and advanced rv frontend

## What do I plan to do next week

-   Work on advance result API
-   Work on PPT
-   Make the backend result API work
-   Finish Advance (if possible)
-   Start creating test cases and word doc
-   Rehearse presentation

## Additional Thoughts

-   Panic is starting to creep in - it's either we have it or we don't
-   Whatever it takes to get it right
-   Lecturer is awesome.
