# Weekly Report

This report is for you to document the progres of your project. You should also document any change in plan, e.g. change in design or change in API specification or change in work allocation. The following is a template for you to follow.

## What have I done last week

-   Worked on...
-   Worked on...
-   Changed....

## What do I plan to do next week

-   Worked on...
-   Worked on...
-   Changed....

## Additional Thoughts

-   VSCode is sick.
-   This addon is fabulous.
-   Lecturer is awesome.
