# Weekly Report

This report is for you to document the progres of your project. You should also document any change in plan, e.g. change in design or change in API specification or change in work allocation. The following is a template for you to follow.

## What have I done last week

-   Roughly discussed about allocating work
-   Setup backend and insert data for backend section
-   We have watched the recap videos
-   Asher has done the development by watching the recap videos by Mr Ang

## What do I plan to do next week
- Query data and result for backend
- Result viewer and data viewer for frontend
- Data viewer (Javascript) for frontend
-   Have a concrete plan of the distribution of work
-   Start our wireframes
-   Finish development by this week
-   After that, we are planning to change our focus from development to wireframes

## Additional Thoughts

-   VSCode is sick.
-   This addon is fabulous.
-   Lecturer is awesome.
