# Weekly Report

This report is for you to document the progres of your project. You should also document any change in plan, e.g. change in design or change in API specification or change in work allocation. The following is a template for you to follow.

## What have I done last week

-   Finished result viewer and data viewer wireframe
-   Started to do meetingtimevoter.md
-   Modified project planning to almost absolute 
-   Setup of frontend and backend(gitignore)

## What do I plan to do next week

-   Work on Justifications
-   Check submission guideline in detail
-   Finish up what has not been finished yet(some worksheets, implement FrontEnd and basic insert api )
-   Communicate even more with our partners

## Additional Thoughts

-  Hope to score better than others(best in class)
-  Not to feel stressed, trying to stay calm

