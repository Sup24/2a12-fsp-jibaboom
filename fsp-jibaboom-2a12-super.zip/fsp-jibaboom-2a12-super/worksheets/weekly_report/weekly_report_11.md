# Weekly Report

This report is for you to document the progres of your project. You should also document any change in plan, e.g. change in design or change in API specification or change in work allocation. The following is a template for you to follow.

## What have I done last week

-   Finished Advance 
-   Finished Validation
-   Finalise the frontend (basic and advanced)
-   Finish frontend test cases word doc
-   Finish backend test cases commenting (test.http)

## What do I plan to do next week

-   Finish Slides
-   Hosting
-   Run the backend test runner (the link provided)
-   Code Style (check)
-   Check Indentations 
-   Finish last 2 weekly reports

## Additional Thoughts

-   ALMOST THERE!!
-   Final weeks!
-   Brain cells dying somehow
-   Is hosting difficult?
-   Worried for demo :(
