# Weekly Report

This report is for you to document the progres of your project. You should also document any change in plan, e.g. change in design or change in API specification or change in work allocation. The following is a template for you to follow.

## What have I done last week

-   Supraja worked on handling previous page error and making frontend data viewer work

## What do I plan to do next week

-   Supraja will work on creating GitHub issues
-   Asher will start working on basic result API
-   Asher will start working on Frontend for Result Viewer

## Additional Thoughts

-   We will not underestimate our time for Phase 2.