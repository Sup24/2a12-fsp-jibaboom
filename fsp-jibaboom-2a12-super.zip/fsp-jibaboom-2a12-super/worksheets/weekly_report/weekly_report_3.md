# Weekly Report

This report is for you to document the progres of your project. You should also document any change in plan, e.g. change in design or change in API specification or change in work allocation. The following is a template for you to follow.

## What have I done last week

-   Project Planning
-   Project Worksheet
-   Started doing Data Viewer Wireframe

## What do I plan to do next week

-   Finish Data Viewer Wireframe
-   Start Result Viewer Wireframe
-   Finish project worksheets(if possible)
-   Monkey Patching 
-   Starting process to tweak the backend to meeting time voter problem
-   Frontend Coding (videos)
-   GitIgnore
-   Generate a list of generic questions to ask Ms Tay

## Additional Thoughts

-  Demo Backend Finished
-  LucidChart (started exploring)
-  Good communication and teamwork
-  Proper understanding of rubrics
-  Have a better idea of what to do 

