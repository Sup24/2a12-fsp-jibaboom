# Weekly Report

This report is for you to document the progres of your project. You should also document any change in plan, e.g. change in design or change in API specification or change in work allocation. The following is a template for you to follow.

## What have I done last week

-   Worked on the algorithm
-   Finished the frontend for basic result viewer
-   Changed wireframes according to new requirements
-   Created new Github issues

## What do I plan to do next week

-   Finish Algorithm
-   Basic Result API: Try to finish
-   Check coding style
-   Prepare for presentation qns (Ask what we don't understand)
-   Double check frontend implementation 
-   Document API
-   Code Advanced Data Viewer Frontend
-   Code Advanced Result Viewer Frontend

## Additional Thoughts

-   Have a developed conceptual understanding of the problem
-   This addon is fabulous.
-   Lecturer is awesome.
