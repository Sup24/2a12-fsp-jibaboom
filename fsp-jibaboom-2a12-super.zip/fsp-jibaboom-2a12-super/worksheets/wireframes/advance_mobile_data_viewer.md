> See example in frontend wireframes
