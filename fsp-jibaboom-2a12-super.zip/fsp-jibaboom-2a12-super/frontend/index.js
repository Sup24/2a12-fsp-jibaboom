var basicDataQuery = {
    meetingId: null,
    participantId: null,
    page: 0,
    pageSize: 5,
};

var advanceDataQuery = {
    meetingId: null,
    participantId: null,
    page: 0,
    pageSize: 5,
};

const basicDataPaginationFunction = {
    gotoFirstPage: function () {
        basicDataQuery['page'] = 0;
    },
    changePageBackward: function (delta) {
        basicDataQuery['page'] += parseInt(delta);
    },
    changePageForward: function (delta) {
        basicDataQuery['page'] += parseInt(delta);
    },
    changePageSize: function (newPageSize) {
        console.log(newPageSize);
        basicDataQuery['pageSize'] = newPageSize;
    },
};

const advanceDataPaginationFunction = {
    gotoFirstPage: function () {
        advanceDataQuery['page'] = 0;
    },
    changePageBackward: function (delta) {
        advanceDataQuery['page'] += parseInt(delta);
    },
    changePageForward: function (delta) {
        advanceDataQuery['page'] += parseInt(delta);
    },
    changePageSize: function (newPageSize) {
        console.log(newPageSize);
        advanceDataQuery['pageSize'] = newPageSize;
    },
};

const basicDataUrl = 'https://fsp-jibaboom-2a12-super.herokuapp.com/basic/data';

const advanceDataUrl = 'https://fsp-jibaboom-2a12-super.herokuapp.com/advance/data';


 


//Result 
const basicResultQuery = {
    meetingId:null,
};
const advanceResultQuery = {
    meetingId:null,
    startTime:null,
    endTime:null,
};
const basicResultUrl = 'https://fsp-jibaboom-2a12-super.herokuapp.com/basic/result';

function populateBasicDataTable(data) {
    console.log(data);
    const dataTableHtml = data.map(
        ({ meetingid,availabilityid,participantid,starttime,endtime }) => `
            <tr>
                <td>${meetingid}</td>
                <td>${availabilityid}</td>
                <td>${participantid}</td>
                <td>${starttime}</td>
                <td>${endtime}</td>
            </tr>
    `,
    );
    $('#basic-data-tbody').html(dataTableHtml);
};
function populateBasicResultTable(data) {
    console.log(data);
    startTime = data.result.fromTime,
    endTime = data.result.toTime,
    result = data.result.participants.map(({participantId}) => `
    <tr>
       <td> ${participantId}</td>
       </tr>
       `
     );
    
    /* const resultTableHtml = data.map(
         ({ participantid}) => `
        
            
    //         <tr>

    //             <td>${participantid}</td>
    //         </tr> */
    // `,
    // );
    $('#basic-result-tbody').html(result);
    $("#fromTime").html(startTime);
    $("#toTime").html(endTime);
};
const advanceResultUrl = 'https://fsp-jibaboom-2a12-super.herokuapp.com/advance/result';
function populateAdvanceResultTable(data) {
    console.log(data);
    
    startTime = data.result.fromTime,
    endTime = data.result.toTime,
    result = data.result.participants.map(({participantId}) => `
    <tr>
       <td> ${participantId}</td>
       </tr>
       `
     );
    
    /* const resultTableHtml = data.map(
         ({ participantid}) => `
        
            
    //         <tr>

    //             <td>${participantid}</td>
    //         </tr> */
    // `,
    // );
    $('#participantId').html(result);
    $("#proposedStartTime").html(startTime);
    //console.log($("#fromTime"));
    $("#proposedEndTime").html(endTime);
    //console.log(startTime);
};

function populateAdvanceDataTable(data) {
    console.log(data);
    const dataTableHtml = data.map(
        ({ meetingid,unavailabilityid,participantid,starttime,endtime }) => `
            <tr>
                <td>${meetingid}</td>
                <td>${unavailabilityid}</td>
                <td>${participantid}</td>
                <td>${starttime}</td>
                <td>${endtime}</td>
            </tr>
    `,
    );
    $('#advance-data-tbody').html(dataTableHtml);
};

function getBasicDataFromBackend(callback) {
    $.get(basicDataUrl, basicDataQuery)
        .done((result) => callback(null, result))
        .fail((message) => callback(message, null));
        console.log(basicDataQuery);
};

function getAdvanceDataFromBackend(callback) {
    $.get(advanceDataUrl, advanceDataQuery)
        .done((result) => callback(null, result))
        .fail((message) => callback(message, null));
        console.log(advanceDataQuery);
};

function refreshBasicDataTable() {
    getBasicDataFromBackend(function(error,data,callback) {
        //if (error) return alert(JSON.stringify(error));
        if (error) {
            return alert("You are already at the first Page");
        }
        /* if (basicDataQuery['page'] = 0){
            if (page = -1) {
                window.alert("You are already at the first Page");
        }
    } */
        populateBasicDataTable(data);
        return false;
    });
};

function refreshAdvanceDataTable() {
    getAdvanceDataFromBackend(function(error,data,callback) {
        //if (error) return alert(JSON.stringify(error));
        if (error) {
            return alert("You are already at the first Page");
        }
        /* if (basicDataQuery['page'] = 0){
            if (page = -1) {
                window.alert("You are already at the first Page");
        }
    } */
        populateAdvanceDataTable(data);
        return false;
    });
};

function filterBasicData(event) {
    
         // check if input is equal to 10
    var meetingId = document.getElementById('meetingId').value;
    var participantId =  document.getElementById('participantId').textContent; 
    console.log(participantId);
    if (participantId != "") {
        if (participantId.length != 10) {
        window.alert("Please enter a number which has 10 digits");
        return false;
      
      // keep form from submitting
        }
};
    if ( meetingId != ""){
         if (meetingId.length != 10) {
        window.alert("Please enter a number which has 10 digits");
        return false;
      
      // keep form from submitting
    }
};
    // else form is good let it submit, of course you will 
    // probably want to alert the user WHAT went wrong.
        
    $('#basic-data-filter-form input').not(':input[type=submit]').each((idx, input) => {
        basicDataQuery[$(input).attr('key')] = $(input).val();
    });
    refreshBasicDataTable();
    return false;
};
function filterBasicResult(event) {
    
        // check if input is not equal to 10
        var meetingId = document.getElementById('meetingId').value;
        
        if (meetingId.length != 10) {
          window.alert("Please enter a number which has 10 digits");
          return false;
          
          // keep form from submitting
        }
       
        // else form is good let it submit, of course you will 
        // probably want to alert the user WHAT went wrong.
       
        
       
    $('#basic-result-filter-form input').not(':input[type=submit]').each((idx, input) => {
        basicResultQuery[$(input).attr('key')] = $(input).val();
    });
    refreshBasicResultTable();
    return false;
}
function filterAdvanceResult(event) {
    // check if input is not equal to 10
    var meetingId = document.getElementById('meetingId').value;
    var fromTime =  document.getElementById('fromTime').value; 
    var toTime =  document.getElementById('toTime').value;
    
    if (meetingId.length != 10) {
      window.alert("Please enter a number which has 10 digits");
      return false;
      
      // keep form from submitting
    } else if (fromTime.length != 4 || toTime.length !=4) {
        window.alert("Please enter a number which has 4 digits");
      return false;
    } else if(fromTime > 2359 || toTime > 2359) {
        window.alert("Please enter a time within 0000 to 2359");
    }
    
    // else form is good let it submit, of course you will 
    // probably want to alert the user WHAT went wrong.
   
    $('#advance-result-filter-form input').not(':input[type=submit]').each((idx, input) => {
        advanceResultQuery[$(input).attr('key')] = $(input).val();
    });
    refreshAdvanceResultTable();
    return false;
};

function filterAdvanceData(event) {
    // check if input is equal to 10
    var meetingId = document.getElementById('meetingId').value;
    var participantId =  document.getElementById('participantId').textContent; 
    if (participantId != "") {
        if (participantId.length != 10) {
            window.alert("Please enter a number which has 10 digits");
            return false;
      // keep form from submitting
    }
};

    if (meetingId != "") {
        if (meetingId.length != 10) {
            window.alert("Please enter a number which has 10 digits");
            return false;
      // keep form from submitting
    }
};
    // else form is good let it submit, of course you will 
    // probably want to alert the user WHAT went wrong.
   
    
    $('#advance-data-filter-form input').not(':input[type=submit]').each((idx, input) => {
        advanceDataQuery[$(input).attr('key')] = $(input).val();
    });
    refreshAdvanceDataTable();
    return false;
};

function registerBasicFilterForm() {
    $('#basic-data-filter-form').submit(filterBasicData);
};
function registerBasicResultFilterForm() {
    $('#basic-result-filter-form').submit(filterBasicResult);
};
function registerAdvanceResultFilterForm() {
    $('#advance-result-filter-form').submit(filterAdvanceResult);
};
function registerAdvanceFilterForm() {
    $('#advance-data-filter-form').submit(filterAdvanceData);
};

function paginateBasicData(event) {
    const fn = $(this).attr('fn');
    const value = $(this).attr('value') || $(this).val();
    basicDataPaginationFunction[fn](value);
    refreshBasicDataTable();
};

function paginateAdvanceData(event) {
    const fn = $(this).attr('fn');
    const value = $(this).attr('value') || $(this).val();
    advanceDataPaginationFunction[fn](value);
    refreshAdvanceDataTable();
};

function registerBasicDataPaginationForm() {
    $('#basic-data-first-page').click(paginateBasicData);
    $('#basic-data-previous-page').click(paginateBasicData);
    $('#basic-data-next-page').click(paginateBasicData);
    $('#basic-data-page-size-select').change(paginateBasicData);
};


function registerAdvanceDataPaginationForm() {
    $('#advance-data-first-page').click(paginateAdvanceData);
    $('#advance-data-previous-page').click(paginateAdvanceData);
    $('#advance-data-next-page').click(paginateAdvanceData);
    $('#advance-data-page-size-select').change(paginateAdvanceData);
};

/* function populateBasicResultTable(data) {
    const dataTableHtml = Object.entries(data.result).map(
        ([participantId,meetingId]) => `
            <tr>
               <td>${participantId}</td>
                <td>${meetingId}</td>
            </tr>
    `,
    );
    $('#basic-result-tbody').html(dataTableHtml);
} 
 */

 function getBasicResultFromBackend(callback) {
    $.get(basicResultUrl, basicResultQuery)
        .done((result) => callback(null, result))
        .fail((message) => callback(message, null));
};

function getAdvanceResultFromBackend(callback) {
    $.get(advanceResultUrl, advanceResultQuery)
        .done((result) => callback(null, result))
        .fail((message) => callback(message, null));
};

function refreshBasicResultTable() {
    getBasicResultFromBackend(function(error, data) {
        if (error) return alert(JSON.stringify(error));
        populateBasicResultTable(data);
    });
}

function refreshAdvanceResultTable() {
    getAdvanceResultFromBackend(function(error, data) {
        if (error) return alert(JSON.stringify(error));
        populateAdvanceResultTable(data);
    });
};

// function compute() {
//     $('#basic-result-input-form input')
//     .not(':input[type-submit]')
//     .each((idx, input) => {
//         basicResultQuery[$(input).attr('key')] = $(input).val();
//     });
//     refreshBasicResultTable();
//     return false;
// }

function registerBasicResultInput() {
    $('#basic-result-input-form').submit(compute);
};

function registerAdvanceResultInput() {
    $('#advance-result-input-form').submit(compute);
};
 
$(document).ready(function(){
    registerBasicFilterForm();
    registerBasicDataPaginationForm();
    //filterBasicData();
    refreshBasicDataTable();
    registerBasicResultFilterForm();
    //registerBasicResultInput();
    //getBasicDataFromBackend();
    //compute();
    registerAdvanceFilterForm();
    registerAdvanceDataPaginationForm();
    // filterAdvanceData();
    refreshAdvanceDataTable();
    registerAdvanceResultFilterForm();
});


/*const basicDataQuery = {
    participantId: null,
    meetingId: null,
    page: 0,
    pageSize: 5,
};
const basicDataPaginationFunction = {
    gotoFirstPage: function () {
        basicDataQuery['page'] = 0;
    },
    changePage: function (delta) {
        basicDataQuery['page'] += parseInt(delta);
    },
    changePageSize: function (newPageSize) {
        console.log(newPageSize);
        basicDataQuery['pageSize'] = newPageSize;
    },
};
const basicDataUrl = 'http://localhost:3000/basic/data';

const basicResultQuery = {
    meetingId: null,
    availabilityId: null,
    participantId: null,
    startTime: null,
    endTime: null,
};

const basicResultUrl = 'http://localhost:3000/basic/result';

function populateBasicDataTable(data) {
    console.log(data);
    const dataTableHtml = data.map(
        ({ meetingId,availabilityId,participantId,startTime,endTime }) => `
            <tr>
                <td>${meetingId}</td>
                <td>${availabilityId}</td>
                <td>${participantId}</td>
                <td>${startTime}</td>
                <td>${endTime}</td>
            </tr>
    `,
    );
    $('#basic-data-tbody').html(dataTableHtml);
}

function getBasicDataFromBackend(callback) {
    $.get(basicDataUrl, basicDataQuery)
        .done((result) => callback(null, result))
        .fail((message) => callback(message, null));
}

function refreshBasicDataTable() {
    getBasicDataFromBackend(function(error, data) {
        if (error) return alert(JSON.stringify(error));
        populateBasicDataTable(data);
    });
}

function filterBasicData(event) {
    $('#basic-data-filter-form input').not(':input[type=submit]').each((idx, input) => {
        basicDataQuery[$(input).attr('key')] = $(input).val();
    });
    refreshBasicDataTable();
    return false;
}

function registerBasicFilterForm() {
    $('#basic-data-filter-form').submit(filterBasicData);
}

function paginateBasicData(event) {
    const fn = $(this).attr('fn');
    const value = $(this).attr('value') || $(this).val();
    basicDataPaginationFunction[fn](value);
    refreshBasicDataTable();
}

function registerBasicDataPaginationForm() {
    $('#basic-data-first-page').click(paginateBasicData);
    $('#basic-data-previous-page').click(paginateBasicData);
    $('#basic-data-next-page').click(paginateBasicData);
    $('#basic-data-page-size-select').change(paginateBasicData);
}

function populateBasicResultTable(data) {
    const dataTableHtml = Object.entries(data.result).map(
        ([meetingId, availabilityId, participantId,startTime,endTime]) => `
            <tr>
                <td>${meetingId}</td>
                <td>${availabilityId}</td>
                <td>${participantId}</td>
                <td>${startTime}</td>
                <td>${endTime}</td>
            </tr>
    `,
    );
    $('#basic-result-tbody').html(dataTableHtml);
}

function getBasicResultFromBackend(callback) {
    $.get(basicResultUrl, basicResultQuery)
        .done((result) => callback(null, result))
        .fail((message) => callback(message, null));
}

function refreshBasicResultTable() {
    getBasicResultFromBackend(function(error, data) {
        if (error) return alert(JSON.stringify(error));
        populateBasicResultTable(data);
    });
}

function compute() {
    $('#basic-result-input-form input')
    .not(':input[type-submit]')
    .each((idx, input) => {
        basicResultQuery[$(input).attr('key')] = $(input).val();
    });
    refreshBasicResultTable();
    return false;
}

function registerBasicResultInput() {
    $('#basic-result-input-form').submit(compute);
}

$(document).ready(function(){
    registerBasicFilterForm();
    registerBasicDataPaginationForm();
    registerBasicResultInput();
    refreshBasicDataTable();
});
*/




/*
const basicDataQuery = {
    participantId: null,
    meetingId: null,
    page: 0,
    pageSize: 5,
};
const basicDataPaginationFunction = {
    gotoFirstPage: function () {
        basicDataQuery['page'] = 0;
    },
    changePage: function (delta) {
        basicDataQuery['page'] += parseInt(delta);
    },
    changePageSize: function (newPageSize) {
        console.log(newPageSize);
        basicDataQuery['pageSize'] = newPageSize;
    },
};
const basicDataUrl = 'http://localhost:3000/basic/data';

const basicResultQuery = {
    countryId: null,
    amount: null,
};

const basicResultUrl = 'http://localhost:3000/basic/result';

function populateBasicDataTable(data) {
    console.log(data);
    const dataTableHtml = data.map(
        ({ meetingId, availabilityId, participantId, startTime, endTime }) => `
            <tr>
                <td>${meetingId}</td>
                <td>${availabilityId}</td>
                <td>${participantId}</td>
                <td>${startTime}</td>
                <td>${endTime}</td>
            </tr>
    `,
    );
    $('#basic-data-tbody').html(dataTableHtml);
}

function getBasicDataFromBackend(callback) {
    $.get(basicDataUrl, basicDataQuery)
        .done((result) => callback(null, result))
        .fail((message) => callback(message, null));
}

function refreshBasicDataTable() {
    getBasicDataFromBackend(function(error, data) {
        if (error) return alert(JSON.stringify(error));
        populateBasicDataTable(data);
    });
}

function filterBasicData(event) {
    $('#basic-data-filter-form input').not(':input[type=submit]').each((idx, input) => {
        basicDataQuery[$(input).attr('key')] = $(input).val();
    });
    refreshBasicDataTable();
    return false;
}

function registerBasicFilterForm() {
    $('#basic-data-filter-form').submit(filterBasicData);
}

function paginateBasicData(event) {
    const fn = $(this).attr('fn');
    const value = $(this).attr('value') || $(this).val();
    basicDataPaginationFunction[fn](value);
    refreshBasicDataTable();
}

function registerBasicDataPaginationForm() {
    $('#basic-data-first-page').click(paginateBasicData);
    $('#basic-data-previous-page').click(paginateBasicData);
    $('#basic-data-next-page').click(paginateBasicData);
    $('#basic-data-page-size-select').change(paginateBasicData);
}

function populateBasicResultTable(data) {
    const dataTableHtml = Object.entries(data.result).map(
        ([coin, count]) => `
            <tr>
                <th scope="row">${coin}</th>
                <td>${count}</td>
            </tr>
    `,
    );
    $('#basic-result-tbody').html(dataTableHtml);
}

function getBasicResultFromBackend(callback) {
    $.get(basicResultUrl, basicResultQuery)
        .done((result) => callback(null, result))
        .fail((message) => callback(message, null));
}

function refreshBasicResultTable() {
    getBasicResultFromBackend(function(error, data) {
        if (error) return alert(JSON.stringify(error));
        populateBasicResultTable(data);
    });
}

function compute() {
    $('#basic-result-input-form input')
    .not(':input[type-submit]')
    .each((idx, input) => {
        basicResultQuery[$(input).attr('key')] = $(input).val();
    });
    refreshBasicResultTable();
    return false;
}

function registerBasicResultInput() {
    $('#basic-result-input-form').submit(compute);
}

$(document).ready(function(){
    registerBasicFilterForm();
    registerBasicDataPaginationForm();
    registerBasicResultInput();
    refreshBasicDataTable();
});



*/




















/* const basicDataQuery = {
    participantId: null,
    meetingId: null,
    page: 0,
    pageSize: 5,
};
const basicDataPaginationFunction = {
    gotoFirstPage: function () {
        basicDataQuery['page'] = 0;
    },
    changePage: function (delta) {
        basicDataQuery['page'] += parseInt(delta);
    },
    changePageSize: function (newPageSize) {
        console.log(newPageSize);
        basicDataQuery['pageSize'] = newPageSize;
    },
};
const basicDataUrl = 'http://localhost:3000/basic/data';

const basicResultQuery = {
    countryId: null,
    amount: null,
};

const basicResultUrl = 'http://localhost:3000/basic/result';

function populateBasicDataTable(data) {
    console.log(data);
    const dataTableHtml = data.map(
        ({ meetingId, availabilityId, participantId, startTime, endTime }) => `
            <tr>
                <td>${meetingId}</td>
                <td>${availabilityId}</td>
                <td>${participantId}</td>
                <td>${startTime}</td>
                <td>${endTime}</td>
            </tr>
    `,
    );
    $('#basic-data-tbody').html(dataTableHtml);
}

function getBasicDataFromBackend(callback) {
    $.get(basicDataUrl, basicDataQuery)
        .done((result) => callback(null, result))
        .fail((message) => callback(message, null));
}

function refreshBasicDataTable() {
    getBasicDataFromBackend(function(error, data) {
        if (error) return alert(JSON.stringify(error));
        populateBasicDataTable(data);
    });
}

function filterBasicData(event) {
    $('#basic-data-filter-form input').not(':input[type=submit]').each((idx, input) => {
        basicDataQuery[$(input).attr('key')] = $(input).val();
    });
    refreshBasicDataTable();
    return false;
}

function registerBasicFilterForm() {
    $('#basic-data-filter-form').submit(filterBasicData);
}

function paginateBasicData(event) {
    const fn = $(this).attr('fn');
    const value = $(this).attr('value') || $(this).val();
    basicDataPaginationFunction[fn](value);
    refreshBasicDataTable();
}

function registerBasicDataPaginationForm() {
    $('#basic-data-first-page').click(paginateBasicData);
    $('#basic-data-previous-page').click(paginateBasicData);
    $('#basic-data-next-page').click(paginateBasicData);
    $('#basic-data-page-size-select').change(paginateBasicData);
}

function populateBasicResultTable(data) {
    const dataTableHtml = Object.entries(data.result).map(
        ([coin, count]) => `
            <tr>
                <th scope="row">${coin}</th>
                <td>${count}</td>
            </tr>
    `,
    );
    $('#basic-result-tbody').html(dataTableHtml);
}

function getBasicResultFromBackend(callback) {
    $.get(basicResultUrl, basicResultQuery)
        .done((result) => callback(null, result))
        .fail((message) => callback(message, null));
}

function refreshBasicResultTable() {
    getBasicResultFromBackend(function(error, data) {
        if (error) return alert(JSON.stringify(error));
        populateBasicResultTable(data);
    });
}

function compute() {
    $('#basic-result-input-form input')
    .not(':input[type-submit]')
    .each((idx, input) => {
        basicResultQuery[$(input).attr('key')] = $(input).val();
    });
    refreshBasicResultTable();
    return false;
}

function registerBasicResultInput() {
    $('#basic-result-input-form').submit(compute);
}

$(document).ready(function(){
    registerBasicFilterForm();
    registerBasicDataPaginationForm();
    registerBasicResultInput();
    refreshBasicDataTable();
}); */